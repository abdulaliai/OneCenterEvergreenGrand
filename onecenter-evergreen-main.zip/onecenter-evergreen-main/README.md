# onecenter-tadhack
TO RUN:

Install Python on your computer
RUN: pip install -r requirements.txt
RUN: export FLASK_APP=main.py OR set FLASK_APP=main.py
RUN: flask run